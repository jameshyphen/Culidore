<?phpif(isset($_GET['r'])){
	if($_GET['r']==1){
	?>
		
		<button>Iets</button>
	<?php
	}

	else {
	?>


		<input></input>
		

	<?php
		}
	}
?>