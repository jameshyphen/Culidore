<?php

$conn = mysqli_connect("mysql096.hosting.combell.com", "ID191774_prods", "Mkj12edcx", "ID191774_prods");

if (!$conn) {
	die("Connectie is niet gelukt: ".mysqli_connect_error());
}

?>