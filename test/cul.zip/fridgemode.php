<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<style>

</style>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="design.css" />
<title>Index</title>
</head>
<body>
<div class="menuvanboven">

<ul>
<a><img src="http://puu.sh/rWbc5/e2826e8a64.png" alt="logo"></a>
<input type="text" name="search" placeholder="Zoeken...">
<li><a href="#">Sign up</a></li>
<li><a href="#">Login</a></li>

</ul>
</div>
<div class="menuvanlinks">
<ul id="logo">
<li ><a id="settings"><img src="http://puu.sh/rWtYi/a8925b96c9.png" alt="logo" width="35px" height="25px"></a></li>

<li class="unchosen"><a href="index.php"><img src="http://puu.sh/rWd4i/0d3e6da086.png" alt="logo" width="35px" height="35px"></a></li>
<li class="unchosen"><a href="favorieten.php"><img src="http://puu.sh/rWePO/c996637cbe.png" alt="logo" width="35px" height="35px"></a></li>
<li class="unchosen"><a href="browsen.php"><img src="http://puu.sh/rWeYR/693b8db04d.png" alt="logo" width="35px" height="35px"></a></li>
<li class="chosen"><a><img src="http://puu.sh/rWf8v/424be36917.png" alt="logo" width="35px" height="35px"></a></li>

</ul>

</div>










</body>
</html>
